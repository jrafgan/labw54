import React, {Component} from 'react';

class GeneratorBtn extends Component {
    constructor() {
        super();
        this.ranks = [2, 3, 4, 5, 6, 7, 8, 9, 10, "j", "q", "k", "a"];
        this.suits = [
            {suit: "diams", symbol: "♦"},
            {suit: "hearts", symbol: "♥"},
            {suit: "clubs", symbol: "♣"},
            {suit: "spades", symbol: "♠"}
        ];
        this.deck = [];
        this.state = {
            inHand: []
        };
        this.createDeck = this.createDeck.bind(this);
        this.getCard = this.getCard.bind(this);
        this.render = this.render.bind(this);
    }

    createDeck() {
        console.log(this.ranks);
        let j = 0;
        this.suits.map(suit => {
            return this.ranks.forEach(rank => {
                let card = {
                    suit: suit.suit,
                    rank: rank,
                    symbol: suit.symbol,
                    key: j
                };
                j++;
                this.deck.push(card);
            })
        });
        console.log(j, this.deck);
    }

    getCard() {
        let randomKey = -0.5 + Math.random() * 52;
        let chosenCard = this.deck.splice(randomKey, 1);
        let copy = this.state.inHand;
        copy.push(chosenCard);
        console.log(this.state.inHand);
        this.setState({inHand: copy});
    }

    render() {
        console.log(this.state.inHand[0]);
        return (
            <div className="playingCards">
                <ul className="deck">
                    <li>...card...</li>
                    ...
                </ul>


                <button type="button" onClick={this.createDeck}>Generator</button>
                <button type="button" onClick={this.getCard}>Get Card</button>
            </div>
        );
    }
}

export default GeneratorBtn;