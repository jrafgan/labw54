import React, { Component } from 'react';
import Card from './card/Cards.js'
import GeneratorBtn from './card/GeneratorBtn.js'
import './card/cards.css'
import './App.css';


class App extends Component {
  state= {
    suit: "diams",
    rank: "k",
    symbol: "♦"

  };
  render() {
    return (
      <div className="App">

        <Card suit={this.state.suit} rank={this.state.rank} symbol={this.state.symbol}/>
        <GeneratorBtn />
      </div>
    );
  }
}

export default App;
